#! /bin/bash
echo -e " \c"
echo "ggg"
line=3
a=`expr 2 \* $line - 1`
