#! /bin/bash
num1=$[2 * 3]
num2=$[1 + 5]
if [ $num1 -eq $num2 ]
then
    echo "Two numbers are equal!"
fi
